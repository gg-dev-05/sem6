/* 
	190001016
	Garvit Galgat
*/

parent(X, Pat).
parent(Liz, X).
parent(X, Y), parent(Y, Pat).